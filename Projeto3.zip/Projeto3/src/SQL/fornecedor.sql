﻿create table fornecedor(
id_for serial,
nome_for character varying(50),
cnpj_for character varying(15),
tel_for character varying(13),
data_cad_for date,
constraint fornecedor_pkey primary key (id_for)
)
