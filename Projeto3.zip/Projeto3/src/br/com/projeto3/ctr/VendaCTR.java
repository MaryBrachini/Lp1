package br.com.projeto3.ctr;

import br.com.projeto3.dto.ClienteDTO;
import br.com.projeto3.dto.VendaDTO;
import br.com.projeto3.dao.VendaDAO;
import br.com.projeto3.dao.ConexaoDAO;
import javax.swing.JTable;

public class VendaCTR {

    VendaDAO vendaDAO = new VendaDAO();

    public VendaCTR() {
    }

    public String inserirVenda(VendaDTO vendaDTO, ClienteDTO clienteDTO, JTable produtos) {
        try {
            if (vendaDAO.inserirVenda(vendaDTO, clienteDTO, produtos)) {
                return "Venda Cadastrada com sucesso!!!";
            } else {
                return "Venda não Cadastrada!!!";
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return "Venda não Cadastrada!!!";
        }
    }

    public String alterarVenda(VendaDTO vendaDTO, ClienteDTO clienteDTO, JTable produtos) {
        try {
            if (vendaDAO.alterarVenda(vendaDTO, clienteDTO, produtos)) {
                return "Venda alterado com sucesso!!!";
            } else {
                return "Venda NAO alterado!!!";
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return "Venda não alterado!!!";
        }
    }

    public String excluirVenda(VendaDTO vendaDTO) {
        try {
            if (vendaDAO.excluirVenda(vendaDTO)) {
                return "Venda excluido com sucesso!!!";
            } else {
                return "Venda Não excluido!!!";
            }
        } catch (Exception e) {

            System.out.println(e.getMessage());
            return "Venda Não excluido!!!";
        }
    }

    public void CloseDB() {
        ConexaoDAO.CloseDB();
    }

}
