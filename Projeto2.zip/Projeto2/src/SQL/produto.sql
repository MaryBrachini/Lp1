﻿create table produto(
id_prod serial,
nome_prod character varying(50),
desc_prod character varying(50),
cod_bar_prod character varying(13),
p_cust_prod double precision,
p_venda_prod double precision,
id_for integer,
constraint produto_pkey primary key (id_prod),
constraint pronecedor_pkey foreign key (id_for) references fornecedor (id_for)
)
